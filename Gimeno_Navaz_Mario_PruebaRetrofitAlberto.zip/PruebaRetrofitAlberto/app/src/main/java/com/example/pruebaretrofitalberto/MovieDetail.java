package com.example.pruebaretrofitalberto;

public class MovieDetail {
    public int id;
    public String title;
    public String overview;
}
